#include <gtest/gtest.h>
#include <QCoreApplication>
#include <QtSql>
#include <QDebug>
#include "db_utils.h"

// Helper for setting up users
void setupTestUser(const QString& table, const QString& name, const QString& email, const QString& pass, const QString& dni) {
    QSqlQuery q;
    if (table == "alumnos_prueba") {
        q.prepare("INSERT INTO alumnos_prueba (nombre, correo, password, DNI, tutor_asignado) VALUES (:n, :e, :p, :d, '')");
    } else {
        q.prepare("INSERT INTO " + table + " (nombre, correo, password, DNI) VALUES (:n, :e, :p, :d)");
    }
    q.bindValue(":n", name); q.bindValue(":e", email); q.bindValue(":p", pass); q.bindValue(":d", dni);
    if (!q.exec()) qDebug() << "Error Setup User:" << q.lastError().text();
}

class ChatAppTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Initialize distinct DB for testing to prevent conflicts
        if (QFile::exists("test_db.db")) QFile::remove("test_db.db");
        initDb("test_db.db");
    }

    void TearDown() override {
        // Optional cleanup
        {
            QSqlDatabase db = QSqlDatabase::database();
            db.close();
        }
        QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
    }
};

TEST_F(ChatAppTest, Assignment) {
    setupTestUser("tutores_prueba", "Profesor X", "tutor@test.com", "1234", "T001");
    setupTestUser("alumnos_prueba", "Alumno Y", "alumno@test.com", "1234", "S001");

    bool assigned = assignStudentToTutor("S001", "T001");
    EXPECT_TRUE(assigned);

    QSqlQuery q;
    q.exec("SELECT tutor_asignado FROM alumnos_prueba WHERE DNI='S001'");
    EXPECT_TRUE(q.next());
    EXPECT_EQ(q.value(0).toString(), "T001");
}

TEST_F(ChatAppTest, Login) {
    setupTestUser("tutores_prueba", "Profesor X", "tutor@test.com", "1234", "T001");

    // Success
    AuthResult res = authenticateUser("tutor@test.com", "1234");
    EXPECT_TRUE(res.success);
    EXPECT_EQ(res.role.toStdString(), "TUTOR");

    // Fail - Wrong Password
    AuthResult failRes = authenticateUser("tutor@test.com", "wrongpass");
    EXPECT_FALSE(failRes.success);

    // Fail - User Not Found
    AuthResult noneRes = authenticateUser("ghost@test.com", "1234");
    EXPECT_FALSE(noneRes.success);
}

TEST_F(ChatAppTest, Messaging) {
    // Blank Handling
    EXPECT_FALSE(canSendMessage(""));
    EXPECT_FALSE(canSendMessage("   "));
    EXPECT_TRUE(canSendMessage("Hola"));

    // Persistence
    QString id = "msg_001";
    QString content = "Contenido de Prueba";
    saveMessage(id, content, "10:00", true, 0, 5000);

    QSqlQuery q;
    q.prepare("SELECT content FROM messages WHERE id = :id");
    q.bindValue(":id", id);
    q.exec();
    EXPECT_TRUE(q.next());
    EXPECT_EQ(q.value(0).toString(), content);
}

TEST_F(ChatAppTest, Alerts) {
    QString sender = "alumno@test.com";
    QString target = "tutor@test.com";
    QString id = "alert_001";
    int priority = 1;

    saveAlert(id, "Content", priority, "12:00", true, 5001, sender, target);

    QSqlQuery q;
    q.prepare("SELECT sender, receiver, priority FROM alerts WHERE id = :id");
    q.bindValue(":id", id);
    q.exec();
    
    EXPECT_TRUE(q.next());
    EXPECT_EQ(q.value("sender").toString(), sender);
    EXPECT_EQ(q.value("receiver").toString(), target);
    EXPECT_EQ(q.value("priority").toInt(), priority);
}

TEST_F(ChatAppTest, Minutes) {
    QString id = "min_001";
    QString title = "Meeting Title";
    QString content = "Things discussed...";
    QString ts = "10:00";
    QString tutor = "tutor@test.com";
    QString student = "student@test.com";
    QString mDate = "2023-01-01";
    QString mTime = "09:30";

    saveMinute(id, title, content, ts, tutor, student, mDate, mTime);

    QSqlQuery q;
    q.prepare("SELECT title, content, tutor_email, student_email, manual_date, manual_time FROM minutes WHERE id = :id");
    q.bindValue(":id", id);
    q.exec();

    EXPECT_TRUE(q.next());
    EXPECT_EQ(q.value("title").toString(), title);
    EXPECT_EQ(q.value("content").toString(), content);
    EXPECT_EQ(q.value("tutor_email").toString(), tutor);
    EXPECT_EQ(q.value("student_email").toString(), student);
    EXPECT_EQ(q.value("manual_date").toString(), mDate);
    EXPECT_EQ(q.value("manual_time").toString(), mTime);
}

TEST_F(ChatAppTest, Notifications) {
    QString id = "notif_001";
    QString user = "user@test.com";
    QString content = "New Alert";
    QString ts = "12:00";

    // 1. Save
    saveNotification(id, user, content, ts);
    
    QSqlQuery q;
    q.prepare("SELECT content FROM notifications WHERE id = :id");
    q.bindValue(":id", id);
    q.exec();
    EXPECT_TRUE(q.next());
    EXPECT_EQ(q.value(0).toString(), content);

    // 2. Clear
    clearNotifications(user);
    
    QSqlQuery q2;
    q2.prepare("SELECT * FROM notifications WHERE user_email = :u");
    q2.bindValue(":u", user);
    q2.exec();
    EXPECT_FALSE(q2.next());
}

int main(int argc, char **argv) {
    QCoreApplication app(argc, argv);
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
