import sqlite3

db_path = "BaseDeDatos.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    # 1. Create Coordinadores Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS coordinadores (
        id TEXT PRIMARY KEY,
        nombre TEXT,
        correo TEXT,
        password TEXT,
        dni TEXT
    )
    """)
    
    # 2. Add columns to minutes table
    try:
        cursor.execute("ALTER TABLE minutes ADD COLUMN tutor_email TEXT")
    except sqlite3.OperationalError: pass
    
    try:
        cursor.execute("ALTER TABLE minutes ADD COLUMN student_email TEXT")
    except sqlite3.OperationalError: pass

    # 3. Insert Default Coordinator
    # Check if exists first
    cursor.execute("SELECT * FROM coordinadores WHERE correo = 'coordinador@universidad.es'")
    if not cursor.fetchone():
        cursor.execute("INSERT INTO coordinadores (id, nombre, correo, password, dni) VALUES (?, ?, ?, ?, ?)",
                       ('1', 'Admin Coordinador', 'coordinador@universidad.es', '12345678', '00000000C'))
        print("Coordinador inserted.")
    else:
        print("Coordinador already exists.")

    conn.commit()
    print("Database updated successfully.")

except Exception as e:
    print(f"Error: {e}")
    conn.rollback()
finally:
    conn.close()
