#!/bin/bash
g++ prueba.cc -o prueba $(pkg-config --cflags --libs Qt5Widgets Qt5Network Qt5Sql)
if [ $? -eq 0 ]; then
    echo "Compilación exitosa. Ejecutable creado: ./prueba"
else
    echo "Error en la compilación."
fi
