#ifndef DB_UTILS_H
#define DB_UTILS_H

#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QString>
#include <QDebug>
#include <QDateTime>

// Structure to return authentication results
struct AuthResult {
    bool success;
    QString role;
    QString email;
    QString dni;
    QString errorMessage;
};

// --- Database Helpers ---

inline void initDb(const QString& dbName = "BaseDeDatos.db") {
    // If connection already exists, remove it to allow re-connection (useful for tests)
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbName);
    if (!db.open()) {
        qDebug() << "Error DB:" << db.lastError().text();
        return;
    }
    
    QSqlQuery q;
    q.exec("CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY, content TEXT, timestamp TEXT, is_mine INTEGER, status INTEGER, remote_port INTEGER)");
    // Ensure legacy schemas are updated or created correctly
    q.exec("CREATE TABLE IF NOT EXISTS alerts (id TEXT PRIMARY KEY, content TEXT, priority INTEGER, timestamp TEXT, is_sent INTEGER, remote_port INTEGER, sender TEXT, receiver TEXT)");
    q.exec("CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, name TEXT, description TEXT, timestamp TEXT)");
    q.exec("CREATE TABLE IF NOT EXISTS minutes (id TEXT PRIMARY KEY, title TEXT, content TEXT, timestamp TEXT, tutor_email TEXT, student_email TEXT)");
    q.exec("CREATE TABLE IF NOT EXISTS chat_messages (id TEXT PRIMARY KEY, sender TEXT, receiver TEXT, content TEXT, timestamp TEXT)");
    q.exec("CREATE TABLE IF NOT EXISTS coordinadores (id TEXT PRIMARY KEY, nombre TEXT, correo TEXT, password TEXT, dni TEXT)");
    
    // Create tables for users if they don't exist (needed for tests if starting fresh)
    q.exec("CREATE TABLE IF NOT EXISTS tutores_prueba (id TEXT PRIMARY KEY, nombre TEXT, correo TEXT, password TEXT, DNI TEXT)");
    q.exec("CREATE TABLE IF NOT EXISTS alumnos_prueba (id TEXT PRIMARY KEY, nombre TEXT, apellidos TEXT, carrera TEXT, correo TEXT, password TEXT, DNI TEXT, tutor_asignado TEXT)");

    // Add columns if they missed in older versions (idempotent operations)
    if (!db.record("tutores_prueba").contains("password")) q.exec("ALTER TABLE tutores_prueba ADD COLUMN password TEXT");
    if (!db.record("alumnos_prueba").contains("password")) q.exec("ALTER TABLE alumnos_prueba ADD COLUMN password TEXT");
    if (!db.record("minutes").contains("tutor_email")) q.exec("ALTER TABLE minutes ADD COLUMN tutor_email TEXT");
    if (!db.record("minutes").contains("student_email")) q.exec("ALTER TABLE minutes ADD COLUMN student_email TEXT");
    if (!db.record("minutes").contains("manual_date")) q.exec("ALTER TABLE minutes ADD COLUMN manual_date TEXT");
    if (!db.record("minutes").contains("manual_time")) q.exec("ALTER TABLE minutes ADD COLUMN manual_time TEXT");
    if (!db.record("alerts").contains("sender")) q.exec("ALTER TABLE alerts ADD COLUMN sender TEXT");
    if (!db.record("alerts").contains("receiver")) q.exec("ALTER TABLE alerts ADD COLUMN receiver TEXT");

    // Notifications Table
    q.exec("CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, user_email TEXT, content TEXT, timestamp TEXT)");

    // Defaults for testing
    q.exec("UPDATE tutores_prueba SET password = '12345678' WHERE password IS NULL");
    q.exec("UPDATE alumnos_prueba SET password = '12345678' WHERE password IS NULL");
}

inline void saveMessage(const QString& id, const QString& content, const QString& timestamp, bool isMine, int status, int remotePort) {
    QSqlQuery query;
    query.prepare("INSERT INTO messages VALUES (:id, :content, :timestamp, :is_mine, :status, :remote_port)");
    query.bindValue(":id", id); query.bindValue(":content", content); query.bindValue(":timestamp", timestamp);
    query.bindValue(":is_mine", isMine ? 1 : 0); query.bindValue(":status", status); query.bindValue(":remote_port", remotePort);
    query.exec();
}

inline void saveAlert(const QString& id, const QString& content, int priority, const QString& timestamp, bool isSent, int remotePort, const QString& sender = "", const QString& receiver = "") {
    QSqlQuery query;
    query.prepare("INSERT INTO alerts (id, content, priority, timestamp, is_sent, remote_port, sender, receiver) VALUES (:id, :content, :priority, :timestamp, :is_sent, :remote_port, :sender, :receiver)");
    query.bindValue(":id", id); query.bindValue(":content", content); query.bindValue(":priority", priority);
    query.bindValue(":timestamp", timestamp); query.bindValue(":is_sent", isSent ? 1 : 0); query.bindValue(":remote_port", remotePort);
    query.bindValue(":sender", sender); query.bindValue(":receiver", receiver);
    query.exec();
}

inline void saveIncident(const QString& id, const QString& name, const QString& description, const QString& timestamp) {
    QSqlQuery query;
    query.prepare("INSERT INTO incidents VALUES (:id, :name, :description, :timestamp)");
    query.bindValue(":id", id); query.bindValue(":name", name); query.bindValue(":description", description);
    query.bindValue(":timestamp", timestamp);
    query.exec();
}

inline void saveMinute(const QString& id, const QString& title, const QString& content, const QString& timestamp, const QString& tutorEmail, const QString& studentEmail, const QString& manualDate, const QString& manualTime) {
    QSqlQuery query;
    query.prepare("INSERT INTO minutes (id, title, content, timestamp, tutor_email, student_email, manual_date, manual_time) VALUES (:id, :title, :content, :timestamp, :tutor, :student, :mdate, :mtime)");
    query.bindValue(":id", id); query.bindValue(":title", title); query.bindValue(":content", content);
    query.bindValue(":timestamp", timestamp); query.bindValue(":tutor", tutorEmail); query.bindValue(":student", studentEmail);
    query.bindValue(":mdate", manualDate); query.bindValue(":mtime", manualTime);
    query.exec();
}

inline void saveChatMessage(const QString& id, const QString& sender, const QString& receiver, const QString& content, const QString& timestamp) {
    QSqlQuery query;
    query.prepare("INSERT INTO chat_messages VALUES (:id, :sender, :receiver, :content, :timestamp)");
    query.bindValue(":id", id); query.bindValue(":sender", sender); query.bindValue(":receiver", receiver);
    query.bindValue(":content", content); query.bindValue(":timestamp", timestamp);
    query.exec();
}

inline void markMessageAsRead(const QString& id) {
    QSqlQuery query;
    query.prepare("UPDATE messages SET status = 1 WHERE id = :id");
    query.bindValue(":id", id);
    query.exec();
}

// --- Notification Helpers ---

inline void saveNotification(const QString& id, const QString& userEmail, const QString& content, const QString& timestamp) {
    QSqlQuery query;
    query.prepare("INSERT INTO notifications (id, user_email, content, timestamp) VALUES (:id, :user, :content, :time)");
    query.bindValue(":id", id); query.bindValue(":user", userEmail); 
    query.bindValue(":content", content); query.bindValue(":time", timestamp);
    query.exec();
}

inline void clearNotifications(const QString& userEmail) {
    QSqlQuery query;
    query.prepare("DELETE FROM notifications WHERE user_email = :user");
    query.bindValue(":user", userEmail);
    query.exec();
}

// --- Logic Helpers ---

inline AuthResult authenticateUser(QString email, QString pass) {
    AuthResult result;
    result.success = false;

    QSqlQuery q;
    
    // Check Coordinator
    q.prepare("SELECT * FROM coordinadores WHERE correo = :email AND password = :pass");
    q.bindValue(":email", email); q.bindValue(":pass", pass);
    if (q.exec() && q.next()) {
        result.success = true;
        result.role = "COORDINADOR";
        result.email = email;
        result.dni = q.value("dni").toString();
        return result;
    }

    // Check Tutor
    q.prepare("SELECT * FROM tutores_prueba WHERE correo = :email AND password = :pass");
    q.bindValue(":email", email); q.bindValue(":pass", pass);
    if (q.exec() && q.next()) {
        result.success = true;
        result.role = "TUTOR";
        result.email = email;
        result.dni = q.value("DNI").toString();
        return result;
    }

    // Check Student
    q.prepare("SELECT * FROM alumnos_prueba WHERE correo = :email AND password = :pass");
    q.bindValue(":email", email); q.bindValue(":pass", pass);
    if (q.exec() && q.next()) {
        result.success = true;
        result.role = "ALUMNO";
        result.email = email;
        result.dni = q.value("DNI").toString();
        return result;
    }

    result.errorMessage = "Correo o contraseña incorrectos.";
    return result;
}

inline bool assignStudentToTutor(QString studentDNI, QString tutorDNI) {
    QSqlQuery q;
    q.prepare("UPDATE alumnos_prueba SET tutor_asignado = :tutor WHERE DNI = :dni");
    q.bindValue(":tutor", tutorDNI);
    q.bindValue(":dni", studentDNI);
    return q.exec();
}

inline bool canSendMessage(QString content) {
    return !content.trimmed().isEmpty();
}

#endif // DB_UTILS_H
