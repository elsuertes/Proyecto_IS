import sqlite3
import random
import string
import os

db_path = "BaseDeDatos.db"
out_file = "credenciales.txt"

def generate_password(length=8):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def update_table(cursor, table_name, file_handle):
    # Select correo only
    cursor.execute(f"SELECT correo FROM {table_name}")
    rows = cursor.fetchall()
    
    file_handle.write(f"\n--- {table_name.upper()} ---\n")
    
    for row in rows:
        email = row[0]
        new_pass = generate_password()
        
        cursor.execute(f"UPDATE {table_name} SET password = ? WHERE correo = ?", (new_pass, email))
        
        file_handle.write(f"User: {email} | Pass: {new_pass}\n")

if not os.path.exists(db_path):
    print("Error: Database not found.")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    with open(out_file, "w") as f:
        # Ensure schema
        try:
            cursor.execute("ALTER TABLE tutores_prueba ADD COLUMN password TEXT")
        except sqlite3.OperationalError:
            pass # Column likely exists
            
        try:
            cursor.execute("ALTER TABLE alumnos_prueba ADD COLUMN password TEXT")
        except sqlite3.OperationalError:
            pass 

        f.write("CREDENCIALES ACTUALIZADAS\n=======================\n")
        update_table(cursor, "tutores_prueba", f)
        update_table(cursor, "alumnos_prueba", f)
    
    conn.commit()
    print("Base de datos actualizada correctamente.")
    print(f"Credenciales guardadas en {out_file}")

except Exception as e:
    print(f"Error: {e}")
    conn.rollback()

finally:
    conn.close()
