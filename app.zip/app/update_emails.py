import sqlite3
import sys

def migrate_emails():
    db_path = "BaseDeDatos.db"
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Tables and columns to update
    targets = [
        ("tutores_prueba", "correo"),
        ("alumnos_prueba", "correo"),
        ("coordinadores", "correo"),
        ("minutes", "tutor_email"),
        ("minutes", "student_email"),
        ("alerts", "sender"),
        ("alerts", "receiver"),
        ("chat_messages", "sender"),
        ("chat_messages", "receiver")
    ]

    domains_to_replace = ["@alum.uco.es"]
    target_domain = "@uco.es"
    
    total_changes = 0

    print("Starting migration...")

    for table, column in targets:
        for old_domain in domains_to_replace:
            # Construct UPDATE query
            # We use REPLACE(col, 'old', 'new')
            query = f"UPDATE {table} SET {column} = REPLACE({column}, ?, ?) WHERE {column} LIKE ?"
            
            # LIKE parameter needs %
            like_pattern = f"%{old_domain}"
            
            try:
                cursor.execute(query, (old_domain, target_domain, like_pattern))
                if cursor.rowcount > 0:
                    print(f"Updated {cursor.rowcount} rows in '{table}.{column}' replacing '{old_domain}' with '{target_domain}'")
                    total_changes += cursor.rowcount
            except sqlite3.OperationalError as e:
                print(f"Skipping {table}.{column} (table/column might not exist): {e}")

    conn.commit()
    conn.close()
    
    print(f"Migration completed. Total rows updated: {total_changes}")

if __name__ == "__main__":
    migrate_emails()
