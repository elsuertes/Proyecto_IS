#!/bin/bash
# Include paths for Qt5
QT_INCLUDES="-I/usr/include/x86_64-linux-gnu/qt5 -I/usr/include/x86_64-linux-gnu/qt5/QtWidgets -I/usr/include/x86_64-linux-gnu/qt5/QtGui -I/usr/include/x86_64-linux-gnu/qt5/QtCore -I/usr/include/x86_64-linux-gnu/qt5/QtNetwork -I/usr/include/x86_64-linux-gnu/qt5/QtSql"
QT_LIBS="-lQt5Widgets -lQt5Core -lQt5Gui -lQt5Network -lQt5Sql"

# GTest Paths
GTEST_DIR="libs/googletest/googletest"

# Create build directory
mkdir -p build
cd build

# Run CMake
cmake ..

# Build
make

# Run tests
if [ $? -eq 0 ]; then
    ./tests
else
    echo "Compilation failed."
    exit 1
fi
