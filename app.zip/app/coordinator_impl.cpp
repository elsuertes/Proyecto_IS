// --- CoordinatorTutorListWindow Implementation ---
CoordinatorTutorListWindow::CoordinatorTutorListWindow(MainMenu* menu, QString m) : menuRef(menu), mode(m) {
    setWindowTitle("Selecciona Tutor");
    resize(400, 600);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0); layout->setSpacing(0);

    // Header
    QWidget* header = new QWidget();
    header->setStyleSheet("background-color: #202C33; padding: 10px;");
    QHBoxLayout* headerLayout = new QHBoxLayout(header);
    QPushButton *backBtn = new QPushButton("⬅");
    backBtn->setFixedSize(30, 30);
    backBtn->setStyleSheet("background: transparent; color: #E9EDEF; font-size: 20px; border: none;");
    connect(backBtn, &QPushButton::clicked, [this](){ this->hide(); if (menuRef) menuRef->show(); });
    headerLayout->addWidget(backBtn);
    QLabel* title = new QLabel("Tutores");
    title->setStyleSheet("font-weight: bold; font-size: 18px; color: #E9EDEF;");
    headerLayout->addWidget(title); headerLayout->addStretch();
    layout->addWidget(header);

    // Content
    scrollArea = new QScrollArea();
    scrollArea->setWidgetResizable(true);
    scrollArea->setStyleSheet("background-color: #0B141A;");
    QWidget *scrollContent = new QWidget();
    listLayout = new QVBoxLayout(scrollContent);
    listLayout->setContentsMargins(20, 20, 20, 20); listLayout->setSpacing(15); listLayout->addStretch();
    scrollArea->setWidget(scrollContent);
    layout->addWidget(scrollArea);
}

void CoordinatorTutorListWindow::loadTutors() {
    QLayoutItem* item;
    while ((item = listLayout->takeAt(0)) != nullptr) {
        if (item->widget()) delete item->widget();
        else if (item->spacerItem()) { listLayout->addItem(item); break; } 
        delete item;
    }

    QSqlQuery q;
    q.prepare("SELECT nombre, apellidos, correo FROM tutores_prueba");
    if (q.exec()) {
        while (q.next()) {
            QString name = q.value("nombre").toString() + " " + q.value("apellidos").toString();
            QString email = q.value("correo").toString();
            
            QPushButton* btn = new QPushButton("🎓 " + name + "\n" + email);
            btn->setStyleSheet("background-color: #202C33; color: #E9EDEF; font-size: 16px; padding: 15px; border-radius: 10px; text-align: left;");
            
            connect(btn, &QPushButton::clicked, [this, email](){
                if (mode == "CHATS") {
                    CoordinatorStudentListWindow* studentWin = new CoordinatorStudentListWindow(menuRef, email);
                    studentWin->loadStudents();
                    studentWin->show();
                } else {
                    if (!menuRef->minutesWindow) menuRef->minutesWindow = new MinutesWindow(menuRef);
                    menuRef->minutesWindow->loadMinutes(email);
                    menuRef->minutesWindow->show();
                }
                this->hide();
            });
            listLayout->insertWidget(listLayout->count() - 1, btn);
        }
    }
}

// --- CoordinatorStudentListWindow Implementation ---
CoordinatorStudentListWindow::CoordinatorStudentListWindow(MainMenu* menu, QString tEmail) : menuRef(menu), tutorEmail(tEmail) {
    setWindowTitle("Selecciona Alumno");
    resize(400, 600);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0); layout->setSpacing(0);

    // Header
    QWidget* header = new QWidget();
    header->setStyleSheet("background-color: #202C33; padding: 10px;");
    QHBoxLayout* headerLayout = new QHBoxLayout(header);
    QPushButton *backBtn = new QPushButton("⬅");
    backBtn->setFixedSize(30, 30);
    backBtn->setStyleSheet("background: transparent; color: #E9EDEF; font-size: 20px; border: none;");
    connect(backBtn, &QPushButton::clicked, [this](){ this->hide(); }); // Go back to tutor list? Ideally yes but simpler to just hide
    headerLayout->addWidget(backBtn);
    QLabel* title = new QLabel("Alumnos de " + tutorEmail);
    title->setStyleSheet("font-weight: bold; font-size: 16px; color: #E9EDEF;");
    headerLayout->addWidget(title); headerLayout->addStretch();
    layout->addWidget(header);

    // Content
    scrollArea = new QScrollArea();
    scrollArea->setWidgetResizable(true);
    scrollArea->setStyleSheet("background-color: #0B141A;");
    QWidget *scrollContent = new QWidget();
    listLayout = new QVBoxLayout(scrollContent);
    listLayout->setContentsMargins(20, 20, 20, 20); listLayout->setSpacing(15); listLayout->addStretch();
    scrollArea->setWidget(scrollContent);
    layout->addWidget(scrollArea);
}

void CoordinatorStudentListWindow::loadStudents() {
    QLayoutItem* item;
    while ((item = listLayout->takeAt(0)) != nullptr) {
        if (item->widget()) delete item->widget();
        else if (item->spacerItem()) { listLayout->addItem(item); break; }
        delete item;
    }

    QSqlQuery q;
    q.prepare("SELECT nombre, apellidos, correo FROM alumnos_prueba WHERE tutor_asignado = (SELECT dni FROM tutores_prueba WHERE correo = :temail)");
    q.bindValue(":temail", tutorEmail);
    if (q.exec()) {
        while (q.next()) {
            QString name = q.value("nombre").toString() + " " + q.value("apellidos").toString();
            QString email = q.value("correo").toString();
            
            QPushButton* btn = new QPushButton("👨‍🎓 " + name + "\n" + email);
            btn->setStyleSheet("background-color: #202C33; color: #E9EDEF; font-size: 16px; padding: 15px; border-radius: 10px; text-align: left;");
            
            connect(btn, &QPushButton::clicked, [this, email](){
                ChatWindow* chat = new ChatWindow(tutorEmail, email, "COORDINADOR", menuRef); // As Coordinator, viewing Tutor-Student chat
                chat->show();
                this->hide();
            });
            listLayout->insertWidget(listLayout->count() - 1, btn);
        }
    }
}
