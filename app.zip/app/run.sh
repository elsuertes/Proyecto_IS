#!/bin/bash
cd "$(dirname "$0")"

# Compile first
g++ -fPIC prueba.cc -o prueba $(pkg-config --cflags --libs Qt5Widgets Qt5Network Qt5Sql)

if [ $? -eq 0 ]; then
    # Run if successful
    ./prueba
else
    # Show error if zenity is installed, otherwise exit
    if command -v zenity &> /dev/null; then
        zenity --error --text="Error de compilación. Revisa el código."
    fi
    exit 1
fi
