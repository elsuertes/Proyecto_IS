/*
 * EJERCICIO 2: Chat con Interfaz Gráfica Qt - Versión Dark, Persistence & Login
 * 
 * Comando de compilación:
 * g++ -fPIC prueba.cc -o prueba $(pkg-config --cflags --libs Qt5Widgets Qt5Network Qt5Sql)
 */

#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QScrollBar>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QUdpSocket>
#include <QHostAddress>
#include <QString>
#include <QByteArray>
#include <QMessageBox>
#include <QDebug>
#include <QDateTime>
#include <QMap>
#include <QTimer>
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDialog>
#include <QFormLayout>

// --- Database Helpers ---

void initDb() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("chat_history.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database failed";
    }

    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS messages ("
               "id TEXT PRIMARY KEY, "
               "content TEXT, "
               "timestamp TEXT, "
               "is_mine INTEGER, "
               "status INTEGER, "
               "remote_port INTEGER)");
}

void saveMessage(const QString& id, const QString& content, const QString& timestamp, bool isMine, int status, int remotePort) {
    QSqlQuery query;
    query.prepare("INSERT INTO messages (id, content, timestamp, is_mine, status, remote_port) "
                  "VALUES (:id, :content, :timestamp, :is_mine, :status, :remote_port)");
    query.bindValue(":id", id);
    query.bindValue(":content", content);
    query.bindValue(":timestamp", timestamp);
    query.bindValue(":is_mine", isMine ? 1 : 0);
    query.bindValue(":status", status);
    query.bindValue(":remote_port", remotePort);
    query.exec();
}

void markMessageAsRead(const QString& id) {
    QSqlQuery query;
    query.prepare("UPDATE messages SET status = 1 WHERE id = :id");
    query.bindValue(":id", id);
    query.exec();
}

// --- UI Helpers ---

QWidget* createMessageWidget(const QString& text, const QString& time, bool isMine, int status, QLabel** statusLabelOut = nullptr) {
    QWidget* widget = new QWidget();
    QHBoxLayout* layout = new QHBoxLayout(widget);
    layout->setContentsMargins(10, 5, 10, 5);

    QWidget* bubble = new QWidget();
    bubble->setStyleSheet(isMine 
        ? "background-color: #005C4B; border-radius: 15px; padding: 10px;" 
        : "background-color: #202C33; border-radius: 15px; padding: 10px;" 
    );
    
    QVBoxLayout* bubbleLayout = new QVBoxLayout(bubble);
    bubbleLayout->setContentsMargins(12, 12, 12, 12);
    bubbleLayout->setSpacing(5);

    QLabel* msgLabel = new QLabel(text);
    msgLabel->setWordWrap(true);
    msgLabel->setStyleSheet("color: #E9EDEF; font-size: 15px; background: transparent;");
    msgLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    bubbleLayout->addWidget(msgLabel);

    QHBoxLayout* metaLayout = new QHBoxLayout();
    metaLayout->addStretch();

    QLabel* timeLabel = new QLabel(time);
    timeLabel->setStyleSheet("color: #8696A0; font-size: 11px; background: transparent;");
    metaLayout->addWidget(timeLabel);

    if (isMine) {
        QString checkText = (status == 1) ? "✓✓" : "✓";
        QString checkColor = (status == 1) ? "#53BDEB" : "#8696A0"; 
        
        QLabel* statusLabel = new QLabel(checkText);
        statusLabel->setStyleSheet(QString("color: %1; font-size: 11px; font-weight: bold; background: transparent; margin-left: 5px;").arg(checkColor));
        
        if (statusLabelOut) *statusLabelOut = statusLabel;
        metaLayout->addWidget(statusLabel);
    }

    bubbleLayout->addLayout(metaLayout);

    if (isMine) {
        layout->addStretch();
        layout->addWidget(bubble);
    } else {
        layout->addWidget(bubble);
        layout->addStretch();
    }
    
    bubble->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
    return widget;
}

// --- Login Dialog ---
class LoginDialog : public QDialog {
public:
    QString role;
    QString email;
    QLineEdit *emailEdit;
    QLineEdit *passEdit;

    LoginDialog(QWidget *parent = nullptr) : QDialog(parent) {
        setWindowTitle("Inicio de Sesión");
        setFixedSize(350, 250);
        setStyleSheet("background-color: #111B21; color: #E9EDEF;");

        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->setSpacing(15);
        layout->setContentsMargins(30, 30, 30, 30);

        QLabel *title = new QLabel("Bienvenido");
        title->setStyleSheet("font-size: 24px; font-weight: bold; color: #00A884; margin-bottom: 10px;");
        title->setAlignment(Qt::AlignCenter);
        layout->addWidget(title);

        emailEdit = new QLineEdit(this);
        emailEdit->setPlaceholderText("Correo (@tutor.es / @alumno.es)");
        emailEdit->setStyleSheet("background-color: #2A3942; border: none; border-radius: 5px; padding: 10px; color: white;");
        
        passEdit = new QLineEdit(this);
        passEdit->setPlaceholderText("Contraseña");
        passEdit->setEchoMode(QLineEdit::Password);
        passEdit->setStyleSheet("background-color: #2A3942; border: none; border-radius: 5px; padding: 10px; color: white;");
        
        QPushButton *loginBtn = new QPushButton("Entrar", this);
        loginBtn->setCursor(Qt::PointingHandCursor);
        loginBtn->setStyleSheet("background-color: #00A884; color: #111B21; border: none; border-radius: 20px; padding: 10px; font-weight: bold;");
        
        layout->addWidget(emailEdit);
        layout->addWidget(passEdit);
        layout->addWidget(loginBtn);
        
        connect(loginBtn, &QPushButton::clicked, this, &LoginDialog::checkLogin);
    }

    void checkLogin() {
        QString inputEmail = emailEdit->text().trimmed();
        if (inputEmail.endsWith("@tutor.es")) {
            role = "TUTOR";
            email = inputEmail;
            accept();
        } else if (inputEmail.endsWith("@alumno.es")) {
            role = "ALUMNO";
            email = inputEmail;
            accept();
        } else {
            QMessageBox::warning(this, "Error", "El correo debe terminar en @tutor.es o @alumno.es para asignar un rol.");
        }
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Estilo Global
    app.setStyle("Fusion");
    QString styleSheet = R"(
        QWidget {
            background-color: #111B21;
            font-family: 'Segoe UI', 'Roboto', 'Helvetica', sans-serif;
            color: #E9EDEF;
        }
        QScrollArea { border: none; background-color: #0B141A; }
        QScrollBar:vertical { border: none; background: #111B21; width: 10px; margin: 0; }
        QScrollBar:handle:vertical { background: #374045; min-height: 20px; border-radius: 5px; }
        QLineEdit { background-color: #2A3942; border: none; border-radius: 20px; padding: 10px 15px; color: #E9EDEF; font-size: 15px; }
        QPushButton { background-color: #00A884; color: #111B21; border: none; border-radius: 20px; padding: 10px 20px; font-weight: bold; }
        QPushButton:hover { background-color: #00C298; }
        QMessageBox { background-color: #202C33; }
        QMessageBox QLabel { color: #E9EDEF; }
    )";
    app.setStyleSheet(styleSheet);

    // --- LOGIN FLOW ---
    LoginDialog login;
    if (login.exec() != QDialog::Accepted) {
        return 0; // Salir si no se loguea
    }
    QString userRole = login.role;
    QString userEmail = login.email;

    // Inicializar DB
    initDb();

    int myPort = 5000;
    int targetPort = 5001;
    if (argc == 3) {
        myPort = atoi(argv[1]);
        targetPort = atoi(argv[2]);
    }

    QWidget window;
    window.setWindowTitle(QString("🌑 Chat %1 - Puerto %2").arg(userRole).arg(myPort));
    window.resize(450, 700);

    QVBoxLayout *layout = new QVBoxLayout(&window);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    // Header
    QWidget* header = new QWidget();
    header->setStyleSheet("background-color: #202C33; padding: 10px;");
    QHBoxLayout* headerLayout = new QHBoxLayout(header);
    
    // Icono de perfil (simulado)
    QLabel* avatar = new QLabel(userRole == "TUTOR" ? "🎓" : "👨‍🎓");
    avatar->setStyleSheet("font-size: 30px; background: transparent;");
    headerLayout->addWidget(avatar);

    QVBoxLayout* titles = new QVBoxLayout();
    QLabel* title = new QLabel("Usuario Remoto");
    title->setStyleSheet("font-weight: bold; font-size: 16px; background: transparent;");
    
    // Mostrar ROL en el header
    QLabel* subtitle = new QLabel(QString("Conectado como: %1 (%2)").arg(userRole).arg(userEmail));
    subtitle->setStyleSheet("color: #00A884; font-size: 12px; font-weight: bold; background: transparent;");
    
    titles->addWidget(title);
    titles->addWidget(subtitle);
    headerLayout->addLayout(titles);
    headerLayout->addStretch();
    layout->addWidget(header);

    // Scroll Area
    QScrollArea *scrollArea = new QScrollArea();
    scrollArea->setWidgetResizable(true);
    scrollArea->setStyleSheet("background-color: #0B141A;");
    
    QWidget *scrollContent = new QWidget();
    scrollContent->setStyleSheet("background-color: #0B141A;");
    QVBoxLayout *scrollLayout = new QVBoxLayout(scrollContent);
    scrollLayout->setContentsMargins(10, 10, 10, 10);
    scrollLayout->setSpacing(10);
    scrollLayout->addStretch(); 
    
    scrollArea->setWidget(scrollContent);
    layout->addWidget(scrollArea);

    // Input Area
    QWidget* inputArea = new QWidget();
    inputArea->setStyleSheet("background-color: #202C33; padding: 10px;");
    QHBoxLayout *inputLayout = new QHBoxLayout(inputArea);
    QLineEdit *messageInput = new QLineEdit();
    messageInput->setPlaceholderText("Escribe un mensaje... ⌨️");
    QPushButton *sendButton = new QPushButton("➤");
    sendButton->setFixedSize(40, 40);
    inputLayout->addWidget(messageInput);
    inputLayout->addWidget(sendButton);
    layout->addWidget(inputArea);

    // Socket UDP
    QUdpSocket *socket = new QUdpSocket(&window);
    socket->bind(QHostAddress::LocalHost, myPort);

    static QMap<QString, QLabel*> pendingAcks;

    // Cargar Historial
    QSqlQuery historyQuery;
    historyQuery.prepare("SELECT id, content, timestamp, is_mine, status FROM messages WHERE remote_port = :port ORDER BY id ASC");
    historyQuery.bindValue(":port", targetPort);
    if (historyQuery.exec()) {
        while (historyQuery.next()) {
            QString id = historyQuery.value("id").toString();
            QString content = historyQuery.value("content").toString();
            QString timestamp = historyQuery.value("timestamp").toString();
            bool isMine = historyQuery.value("is_mine").toBool();
            int status = historyQuery.value("status").toInt();

            QLabel* statusLabel = nullptr;
            QWidget* bubble = createMessageWidget(content, timestamp, isMine, status, &statusLabel);
            scrollLayout->addWidget(bubble);

            if (isMine && status == 0 && statusLabel) {
                pendingAcks.insert(id, statusLabel);
            }
        }
    }
    
    QTimer::singleShot(100, [scrollArea](){
        scrollArea->verticalScrollBar()->setValue(scrollArea->verticalScrollBar()->maximum());
    });

    auto scrollToBottom = [scrollArea]() {
        QScrollBar *sb = scrollArea->verticalScrollBar();
        sb->setValue(sb->maximum());
    };

    // Lógica de Recepción
    QObject::connect(socket, &QUdpSocket::readyRead, [socket, scrollLayout, targetPort, scrollToBottom]() {
        while (socket->hasPendingDatagrams()) {
            QByteArray datagram;
            datagram.resize(socket->pendingDatagramSize());
            QHostAddress sender;
            quint16 senderPort;
            socket->readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);
            
            QString rawData = QString::fromUtf8(datagram);
            QStringList parts = rawData.split("|");

            if (parts.size() >= 2) {
                QString type = parts[0];
                QString id = parts[1];

                if (type == "MSG" && parts.size() >= 3) {
                    QString content = parts.mid(2).join("|");
                    QString time = QDateTime::currentDateTime().toString("HH:mm");
                    
                    saveMessage(id, content, time, false, 1, targetPort);

                    QWidget* bubble = createMessageWidget(content, time, false, 0);
                    scrollLayout->addWidget(bubble);
                    QTimer::singleShot(10, scrollToBottom);

                    QString ackMsg = "ACK|" + id;
                    socket->writeDatagram(ackMsg.toUtf8(), QHostAddress::LocalHost, targetPort);

                    QMessageBox::information(nullptr, "📩 Nuevo Mensaje", content);
                    QApplication::alert(socket->parent()->isWidgetType() ? (QWidget*)socket->parent() : nullptr);
                }
                else if (type == "ACK") {
                    markMessageAsRead(id);
                    if (pendingAcks.contains(id)) {
                        QLabel* statusLabel = pendingAcks[id];
                        if (statusLabel) {
                            statusLabel->setText("✓✓");
                            statusLabel->setStyleSheet("color: #53BDEB; font-size: 11px; font-weight: bold; background: transparent; margin-left: 5px;");
                        }
                        pendingAcks.remove(id);
                    }
                }
            }
        }
    });

    // Lógica de Envío
    auto sendMessage = [socket, messageInput, scrollLayout, targetPort, scrollToBottom]() {
        QString text = messageInput->text();
        if (text.isEmpty()) return;

        QString id = QString::number(QDateTime::currentMSecsSinceEpoch());
        QString time = QDateTime::currentDateTime().toString("HH:mm");

        saveMessage(id, text, time, true, 0, targetPort);

        QString packet = "MSG|" + id + "|" + text;
        socket->writeDatagram(packet.toUtf8(), QHostAddress::LocalHost, targetPort);

        QLabel* statusLabel = nullptr;
        QWidget* bubble = createMessageWidget(text, time, true, 0, &statusLabel);
        scrollLayout->addWidget(bubble);
        QTimer::singleShot(10, scrollToBottom);

        if (statusLabel) {
            pendingAcks.insert(id, statusLabel);
        }

        messageInput->clear();
    };

    QObject::connect(sendButton, &QPushButton::clicked, sendMessage);
    QObject::connect(messageInput, &QLineEdit::returnPressed, sendMessage);

    window.show();
    return app.exec();
}
