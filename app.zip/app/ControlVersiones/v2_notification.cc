/*
 * VERSION 2: Chat con Notificaciones
 * 
 * Funcionalidad:
 * - Añadido QMessageBox al recibir mensajes.
 * - Añadido QApplication::alert.
 * 
 * Compilar: g++ -fPIC v2_notification.cc -o v2 $(pkg-config --cflags --libs Qt5Widgets Qt5Network)
 */

#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QUdpSocket>
#include <QHostAddress>
#include <QMessageBox>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    int myPort = 5000;
    int targetPort = 5001;
    if (argc == 3) {
        myPort = atoi(argv[1]);
        targetPort = atoi(argv[2]);
    }

    QWidget window;
    window.setWindowTitle(QString("Chat v2 - Puerto %1").arg(myPort));
    window.resize(400, 500);

    QVBoxLayout *layout = new QVBoxLayout(&window);

    QTextEdit *chatHistory = new QTextEdit();
    chatHistory->setReadOnly(true);
    layout->addWidget(chatHistory);

    QHBoxLayout *inputLayout = new QHBoxLayout();
    QLineEdit *messageInput = new QLineEdit();
    QPushButton *sendButton = new QPushButton("Enviar");
    
    inputLayout->addWidget(messageInput);
    inputLayout->addWidget(sendButton);
    layout->addLayout(inputLayout);

    QUdpSocket *socket = new QUdpSocket(&window);
    socket->bind(QHostAddress::LocalHost, myPort);

    QObject::connect(socket, &QUdpSocket::readyRead, [socket, chatHistory]() {
        while (socket->hasPendingDatagrams()) {
            QByteArray datagram;
            datagram.resize(socket->pendingDatagramSize());
            socket->readDatagram(datagram.data(), datagram.size());
            QString msg = QString::fromUtf8(datagram);
            chatHistory->append("Ellos: " + msg);
            
            QMessageBox::information(nullptr, "Nuevo Mensaje", "Has recibido: " + msg);
            QApplication::alert(chatHistory->window());
        }
    });

    auto sendMessage = [socket, messageInput, chatHistory, targetPort]() {
        QString text = messageInput->text();
        if (text.isEmpty()) return;
        socket->writeDatagram(text.toUtf8(), QHostAddress::LocalHost, targetPort);
        chatHistory->append("Yo: " + text);
        messageInput->clear();
    };

    QObject::connect(sendButton, &QPushButton::clicked, sendMessage);
    QObject::connect(messageInput, &QLineEdit::returnPressed, sendMessage);

    window.show();
    return app.exec();
}
