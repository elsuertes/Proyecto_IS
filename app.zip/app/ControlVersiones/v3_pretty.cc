/*
 * VERSION 3: Tema Claro Profesional
 * 
 * Funcionalidad:
 * - Estilos CSS (Qt Stylesheets).
 * - Burbujas HTML.
 * - Emoticonos.
 * 
 * Compilar: g++ -fPIC v3_pretty.cc -o v3 $(pkg-config --cflags --libs Qt5Widgets Qt5Network)
 */

#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QUdpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include <QDateTime>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    app.setStyle("Fusion");
    
    // Estilos Light
    app.setStyleSheet(R"(
        QWidget { background-color: #F0F2F5; color: #1C1E21; font-family: sans-serif; }
        QTextEdit { background-color: white; border-radius: 10px; padding: 10px; }
        QLineEdit { background-color: white; border-radius: 20px; padding: 8px 15px; }
        QPushButton { background-color: #0084FF; color: white; border-radius: 20px; padding: 8px 20px; font-weight: bold; }
    )");

    int myPort = 5000;
    int targetPort = 5001;
    if (argc == 3) {
        myPort = atoi(argv[1]);
        targetPort = atoi(argv[2]);
    }

    QWidget window;
    window.setWindowTitle(QString("💬 Chat v3 - Puerto %1").arg(myPort));
    window.resize(450, 600);

    QVBoxLayout *layout = new QVBoxLayout(&window);
    layout->setContentsMargins(20, 20, 20, 20);

    QTextEdit *chatHistory = new QTextEdit();
    chatHistory->setReadOnly(true);
    layout->addWidget(chatHistory);

    QHBoxLayout *inputLayout = new QHBoxLayout();
    QLineEdit *messageInput = new QLineEdit();
    messageInput->setPlaceholderText("Escribe... ✍️");
    QPushButton *sendButton = new QPushButton("Enviar 🚀");
    
    inputLayout->addWidget(messageInput);
    inputLayout->addWidget(sendButton);
    layout->addLayout(inputLayout);

    QUdpSocket *socket = new QUdpSocket(&window);
    socket->bind(QHostAddress::LocalHost, myPort);

    QObject::connect(socket, &QUdpSocket::readyRead, [socket, chatHistory]() {
        while (socket->hasPendingDatagrams()) {
            QByteArray datagram;
            datagram.resize(socket->pendingDatagramSize());
            socket->readDatagram(datagram.data(), datagram.size());
            QString msg = QString::fromUtf8(datagram);
            QString time = QDateTime::currentDateTime().toString("HH:mm");
            
            chatHistory->append(QString("<div style='color: #65676B; font-size: 10px;'>Ellos • %1</div>"
                                      "<div style='background: #E4E6EB; padding: 8px; border-radius: 15px;'>%2</div>").arg(time).arg(msg));
            
            QMessageBox::information(nullptr, "🔔 Nuevo Mensaje", msg);
            QApplication::alert(chatHistory->window());
        }
    });

    auto sendMessage = [socket, messageInput, chatHistory, targetPort]() {
        QString text = messageInput->text();
        if (text.isEmpty()) return;
        socket->writeDatagram(text.toUtf8(), QHostAddress::LocalHost, targetPort);
        
        QString time = QDateTime::currentDateTime().toString("HH:mm");
        chatHistory->append(QString("<div align='right' style='color: #65676B; font-size: 10px;'>%1 • Tú</div>"
                                  "<div align='right' style='background: #0084FF; color: white; padding: 8px; border-radius: 15px;'>%2</div>").arg(time).arg(text));
        messageInput->clear();
    };

    QObject::connect(sendButton, &QPushButton::clicked, sendMessage);
    QObject::connect(messageInput, &QLineEdit::returnPressed, sendMessage);

    window.show();
    return app.exec();
}
