/*
 * VERSION 4: Dark Mode & Read Receipts
 * 
 * Funcionalidad:
 * - Tema Oscuro (WhatsApp style).
 * - Protocolo MSG/ACK para confirmación de lectura.
 * - QScrollArea para evitar corte de texto.
 * 
 * Compilar: g++ -fPIC v4_dark.cc -o v4 $(pkg-config --cflags --libs Qt5Widgets Qt5Network)
 */

#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QUdpSocket>
#include <QMessageBox>
#include <QDateTime>
#include <QMap>
#include <QTimer>

// Helper simplificado para v4
QWidget* createBubble(const QString& text, bool isMine, QLabel** statusOut = nullptr) {
    QWidget* w = new QWidget();
    QHBoxLayout* l = new QHBoxLayout(w);
    QLabel* lbl = new QLabel(text);
    lbl->setStyleSheet(isMine ? "background: #005C4B; color: white; padding: 10px; border-radius: 10px;" 
                              : "background: #202C33; color: white; padding: 10px; border-radius: 10px;");
    
    if (isMine) {
        l->addStretch();
        l->addWidget(lbl);
        if (statusOut) {
            *statusOut = new QLabel("✓");
            (*statusOut)->setStyleSheet("color: gray;");
            l->addWidget(*statusOut);
        }
    } else {
        l->addWidget(lbl);
        l->addStretch();
    }
    return w;
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    app.setStyle("Fusion");
    app.setStyleSheet("QWidget { background: #111B21; color: white; } QLineEdit { background: #2A3942; }");

    int myPort = 5000;
    int targetPort = 5001;
    if (argc == 3) { myPort = atoi(argv[1]); targetPort = atoi(argv[2]); }

    QWidget window;
    window.setWindowTitle("Dark Chat v4");
    window.resize(400, 600);
    QVBoxLayout* layout = new QVBoxLayout(&window);

    QScrollArea* scroll = new QScrollArea();
    scroll->setWidgetResizable(true);
    QWidget* content = new QWidget();
    QVBoxLayout* scrollLayout = new QVBoxLayout(content);
    scrollLayout->addStretch();
    scroll->setWidget(content);
    layout->addWidget(scroll);

    QHBoxLayout* inputLayout = new QHBoxLayout();
    QLineEdit* input = new QLineEdit();
    QPushButton* btn = new QPushButton("➤");
    inputLayout->addWidget(input);
    inputLayout->addWidget(btn);
    layout->addLayout(inputLayout);

    QUdpSocket* socket = new QUdpSocket(&window);
    socket->bind(QHostAddress::LocalHost, myPort);
    static QMap<QString, QLabel*> acks;

    QObject::connect(socket, &QUdpSocket::readyRead, [socket, scrollLayout, targetPort]() {
        while (socket->hasPendingDatagrams()) {
            QByteArray d; d.resize(socket->pendingDatagramSize());
            socket->readDatagram(d.data(), d.size());
            QStringList p = QString::fromUtf8(d).split("|");
            
            if (p[0] == "MSG") {
                scrollLayout->addWidget(createBubble(p[2], false));
                socket->writeDatagram(("ACK|" + p[1]).toUtf8(), QHostAddress::LocalHost, targetPort);
                QMessageBox::information(nullptr, "Msg", p[2]);
            } else if (p[0] == "ACK" && acks.contains(p[1])) {
                acks[p[1]]->setText("✓✓");
                acks[p[1]]->setStyleSheet("color: #53BDEB;");
            }
        }
    });

    auto send = [socket, input, scrollLayout, targetPort]() {
        QString txt = input->text();
        if (txt.isEmpty()) return;
        QString id = QString::number(QDateTime::currentMSecsSinceEpoch());
        socket->writeDatagram(("MSG|" + id + "|" + txt).toUtf8(), QHostAddress::LocalHost, targetPort);
        
        QLabel* status = nullptr;
        scrollLayout->addWidget(createBubble(txt, true, &status));
        if (status) acks.insert(id, status);
        input->clear();
    };

    QObject::connect(btn, &QPushButton::clicked, send);
    window.show();
    return app.exec();
}
